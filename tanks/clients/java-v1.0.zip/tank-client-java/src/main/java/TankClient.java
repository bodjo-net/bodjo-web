import com.bodjo.tank_wrapper.Client;
import com.bodjo.tank_wrapper.pojo.GameData;
import com.bodjo.tank_wrapper.pojo.ReturnModel;

import java.util.Random;

public class TankClient {
    public static void main(String...args){
        new Client().run("<your-login>", "<your-password>", (GameData data) -> {
            float xv = new Random().nextFloat();
            float yv = new Random().nextFloat();
            return new ReturnModel(
                    new float[]{xv, yv},
                    new Random().nextFloat(),
                    true);
        });
    }
}