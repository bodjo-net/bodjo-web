/*
	Bodjo Tanks Bot v1.0 (v2.5 protocol)

	dkaraush@gmail.com
*/

const apiURL = "https://vkram.shpp.me:3518";
const apiHostname = "vkram.shpp.me";
const apiPort = 3518;
const gameURL = "wss://vkram.shpp.me:{port}";

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;

var readline, http, https, fs, ws, Writable;
try {
	require('colors');
	readline = require('readline');
	http = require('http');
	https = require('https');
	ws = require('ws');
	fs = require('fs');
	Writable = require('stream').Writable;
} catch (e) {
	console.log("Libraries aren't loaded.\nDo 'npm install' first");
}

Object.getOwnPropertyNames(Math).forEach(function(n){global[n]=Math[n]});
function range(x, _min, _max) {
	return min(max(x, _min), _max);
}

var mutableStdout = new Writable({
  write: function(chunk, encoding, callback) {
    if (!this.muted)
      process.stdout.write(chunk, encoding);
    callback();
  }
});
mutableStdout.muted = false;

const Q = readline.createInterface({
	input: process.stdin,
	output: mutableStdout,
	terminal: true
});

var gameServerPort = null;
var credentials = {};
var userToken = null;
function checkGameServer(callback) {
	// check that 'tanks' server works
	HTTPSrequest('GET', '/services', {}, function (obj) {
		var gameServerObject = obj.services.filter(function (service) {
			return service.name == 'tanks'
		})[0];
		if (!gameServerObject)
			errFatal('Game server \'Tanks\' is dead now. Probably something goes wrong on server side.')

		gameServerPort = gameServerObject.port;
		log('Game Server \'Tanks\' is working at :' + gameServerPort);

		callback();

	}, function (e) {
		errFatal('Main server doesn\'t respond. Check your network connection.', e);
	})
}

function checkCredentials(credentials, callback) {
	if (credentials.username && credentials.password) {
		HTTPSrequest('POST', '/login', {
			username: credentials.username,
			password: credentials.password
		}, function (obj) {
			if (obj.status == 'ok') {
				userToken = obj.token;
				callback(true);
			} else {
				warn(JSON.stringify(obj))
				callback(false);
			}
		}, function (e) {
			err('Tried to check username&password', e)
			callback(false)
		})
	} else if (credentials.username && credentials.gameSessionToken) {
		var socket = new ws(gameURL.replace(/{port}/g, gameServerPort));
		socket.on('open', function () {
			socket.send(JSON.stringify({
				type: 'connect',
				username: credentials.username,
				token: credentials.gameSessionToken,
				role: 'player'
			}));
		});
		socket.on('message', function (data) {
			if (typeof data === 'string') {
				var obj = JSON.parse(data);
				if (obj.type == 'connect') {
					if (obj.status == 'ok') {
						socket.close();
						callback(true);
					} else if (obj.errCode == 2) {
						errFatal('Player has already connected. Switch in bodjo.net/tanks to a spectator and try again.');
						callback(false);
					} else {
						err(JSON.stringify(obj))
						callback(false);
					}
				}
			}
		});
		socket.on('error', err)
	} else {
		err('checkCredentials(): bad keys collection [' + Object.keys(credentials).join(',') + ']');
		callback(false);
	}
}

var config = null;
function getCredentials(callback) {
	if (fs.existsSync('config.json')) {
		try {
			config = JSON.parse(fs.readFileSync('config.json'));
		} catch (e) {
			errFatal('config.json'.magenta + ' is broken or permission is denied.', e);
		}
	} else {
		warn('' + 'config.json'.magenta + ' is missing; created new.');
		fs.writeFileSync('config.json', '{\n\n}');
		config = {};
	}

	if (!((config.username && config.password) ||
		  (config.username && config.gameSessionToken))) {
		warn('credentials in ' + 'config.json'.magenta + ' are missing.');
		promptCredentials(callback);
	} else {
		checkCredentials(config, function (status) {
			if (status) {
				log('Have checked credentials: ' + 'Success'.green.bold);
				credentials = config;
				callback();
			} else {
				warn('Bad credentials.');
				promptCredentials(callback);
			}
		})
	}
}
function promptCredentials(callback) {
	log('=============')
	log('To connect to server you should know your '+'username'.cyan+' and '+'password'.cyan+'/'+'gameSessionToken'.cyan+'.');
	log('Which type of credentials do you prefer?')
	log('0'.blue + ' - '+'username'.cyan+' and '+'password'.cyan+' (it will not be expired)');
	log('1'.blue + ' - '+'username'.cyan+' and '+'gameSessionToken'.cyan+' (more secure)');
	log('exit'.blue + ' - exit');
	function ask() {
		Q.question('> ', function (answer) {
			if (answer == 'exit') {
				process.exit(0)
			} else if (answer == '0') {
				(function prompt0() {
					Q.question('Username: ', function (username) {
						Q.question('Password: ', function (password) {
							mutableStdout.muted=false;
							checkCredentials({
								username: username,
								password: password
							}, function (status) {
								if (!status) {
									warn('Bad login/password. Try again.');
									prompt0();
								} else {
									credentials.username = config.username = username;
									credentials.password = config.password = password;
									log('Success.'.green.bold + ' Saved in ' + 'config.json'.magenta);
									fs.writeFileSync('config.json', JSON.stringify(config, null, '\t'));
									callback();
								}
							});
						})
						mutableStdout.muted=true;
					});
				})();
			} else if (answer == '1') {
				(function prompt1() {
					Q.question('Username: ', function (username) {
						Q.question('GameSessionToken (copy from bodjo.net/tanks): ', function (token) {
						mutableStdout.muted=false;
							checkCredentials({
								username: username,
								gameSessionToken: token
							}, function (status) {
								if (!status) {
									warn('Bad login/gameSessionToken. Try again.');
									prompt1();
								} else {
									credentials.username = config.username = username;
									credentials.gameSessionToken = config.gameSessionToken = token;
									log('Success.'.green.bold);
									fs.writeFileSync('config.json', JSON.stringify(config, null, '\t'));
									callback();
								}
							});
						});
						mutableStdout.muted=true;
					});
				})();
			} else {
				warn('bad answer.');
				ask();
			}
		})
	}
	ask();
}
function start() {
	if (credentials.username && credentials.password) {
		getGameSessionToken(function (gameSessionToken) {
			credentials.gameSessionToken = gameSessionToken;
			connect(credentials);
		})
	} else if (credentials.username && credentials.gameSessionToken) {
		connect(credentials);
	}
}
var code = null, usernames = {};
var badAttempts = 0;
function connect(credentials) {
	log('Connecting to ' + gameURL.replace(/{port}/g, gameServerPort))
	var socket = new ws(gameURL.replace(/{port}/g, gameServerPort));
	socket.on('open', function () {
		socket.send(JSON.stringify({
			type: 'connect',
			username: credentials.username,
			token: credentials.gameSessionToken,
			role: 'player'
		}));
	});
	var isPlaying = false;
	socket.on('close', function () {
		warn("websocket was closed.");
		if (watchdogInterval)
			clearInterval(watchdogInterval)
		if (badAttempts > 2)
			errFatal("Tried to connect three times: " + "unsuccessfully".red.bold);
		badAttempts++;
		setTimeout(function () {
			log("trying to connect again");
			connect(credentials);
		}, 1000);
	});
	socket.on('error', function (e) {
		warn("websocket onerror()", e);
		if (watchdogInterval)
			clearInterval(watchdogInterval)
		if (badAttempts > 2)
			errFatal("Tried to connect three times: " + "unsuccessfully".red.bold);
		badAttempts++;
		setTimeout(function () {
			log("trying to connect again");
			connect(credentials);
		}, 1000);
	});
	var lastSuccessfulTick = -1, watchdogInterval = -1;
	socket.on('message', function (data) {
		if (typeof data === 'string') {
			var obj = JSON.parse(data);
			if (obj.type == 'connect') {
				if (obj.status == 'ok') {
					log('Connected ' + 'successfully'.green.bold);
				} else if (obj.errCode == 2) {
					errFatal('Player has already connected. Switch in bodjo.net/tanks to a spectator and try again.');
				} else {
					err('Connection error.');
					err(JSON.stringify(obj,null,'\t'));
					process.exit(0);
				}
			} else if (obj.type == 'const') {
				Object.keys(obj).filter(function(key){return key!='type'}).forEach(function (key) {
					global[key] = obj[key];
				});
				log('Constants are loaded. Ready to play.');
			}
		} else {
			var parsed = parseData(data);
			if (parsed.messageType == 'game') {

				if (!isPlaying) {
					socket.send(JSON.stringify({
						type: 'start'
					}));
					isPlaying = true;
					log("Bot is started.")
					return;
				}
				if (!parsed.me)
					return;

				var first = false;
				if (code == null) {
					first = true;
					try {
						code = require('./your-code-here.js');
					} catch (e) {
						errFatal("Importing code ("+'your-code-here.js'.magenta+") error", e);
					}
				}
				if (typeof code !== 'function')
					errFatal("onTick (module.exports) ("+'your-code-here.js'.magenta+") is not a function.\nHave you forgotten to write 'module.exports = onTick;'?");
				
				var response;
				try {
					response = code(parsed)
				} catch (e) {
					errFatal("Error while running code in "+'your-code-here.js'.magenta, e);
				}

				if (!(typeof response === 'object' &&
					Array.isArray(response.move) &&
					response.move.length == 2 &&
					response.move[0] >= -1 && response.move[0] <= 1 &&
					response.move[1] >= -1 && response.move[1] <= 1 &&
					typeof response.headAngle === 'number' &&
					Number.isFinite(response.headAngle) &&
					typeof response.shoot === 'boolean')) {
					errFatal("Code returned bad response: \n" + JSON.stringify(response,'','\t'));
				}

				socket.send(makeMessage(response));
				badAttempts = 0;
				lastSuccessfulTick = Date.now();
				if (first) {
					log('First tick response went ' + 'successfully'.green.bold + '. Bot is playing right now!');
					if (watchdogInterval != -1)
						watchdogInterval = setInterval(function () {
							if (Date.now() - lastSuccessfulTick > 5000) {
								warn("Client hasn't received any messages for 5 seconds. Try to connect again...");
								clearInterval(watchdogInterval);
								lastSuccessfulTick = -1;
								setTimeout(function () {
									log("trying to connect again");
									connect(credentials);
								}, 1000);
							}
						}, 5000);
				}
			} else if (parsed.messageType == 'score') {
				var scoreboard = parsed.scoreboard;
				for (var i = 0; i < scoreboard.length; ++i) {
					if (typeof scoreboard[i].id !== 'undefined')
						usernames[scoreboard[i].id] = scoreboard[i].username;
				}
			}
		}
	});
}
function makeMessage(data) {
	// var buffer = new ArrayBuffer(13);
	// var bufferView = new DataView(buffer);
	// bufferView.setFloat32(0, data.headAngle % (Math.PI*2));
	// bufferView.setFloat32(4, data.move[0]);
	// bufferView.setFloat32(8, data.move[1]);
	// bufferView.setInt8(12, !!data.shoot-0);
	var buffer = new ArrayBuffer(4);
	var bufferView = new DataView(buffer);
	bufferView.setUint16(0, (round(data.headAngle % (Math.PI*2) / (Math.PI*2) * (Math.pow(2, 15)-1)) << 1) + (data.shoot-0));
	var angle = Math.atan2(data.move[1], data.move[0]);
	var speed = range(Math.sqrt(Math.pow(data.move[1], 2) + Math.pow(data.move[0], 2)), 0, 1);
	bufferView.setUint8(2, angle / (Math.PI*2) * 255);
	bufferView.setUint8(3, speed * 255);
	return bufferView;
}
const colors = [
	'red', 'blue', 'black', 'green', 'beige'
];
const max8 = 255;
const max16 = 65535;
var id = -1;
const symbolsRange = ' 1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM_-';
function parseData(data) {
	data = toArrayBuffer(data);

	var offset = 0;
	var type = new Uint8Array(data.slice(offset, offset+=1))[0];
	if (type == 0) {
		var O = {messageType: 'game'};
		O.time = new Uint32Array(data.slice(offset, offset+=4))[0];

		var playersCount = new Uint8Array(data.slice(offset, offset+=1))[0];
		O.players = new Array(playersCount);
		O.enemies = new Array();
		for (var i = 0; i < playersCount; ++i) {
			var pO = {};
			var d1 = new Uint8Array(data.slice(offset, offset+=2));
			var d2 = new Uint16Array(data.slice(offset, offset+=8));
			var d3 = new Uint8Array(data.slice(offset, offset+=3));
			pO.id = d1[0];
			pO.username = usernames[d1[0]] || '...';
			pO.color = colors[d1[1]];
			pO.x = d2[0] / max16 * width;
			pO.y = d2[1] / max16 * height;
			pO.vx = round((d2[2] / max16 * 2 - 1)*100)/100 / TPS * 2.5;
			pO.vy = round((d2[3] / max16 * 2 - 1)*100)/100 / TPS * 2.5;
			pO.angle = atan2(pO.vy, pO.vx);
			pO.hp = d3[0] / max8;
			pO.lastShot = d3[1];
			pO.bonuses = {};
			pO.bonuses.heal = d3[2] == 1 || d3[2] == 3;
			pO.bonuses.ammo = d3[2] == 2 || d3[2] == 3;
			// pO.headAngle = new Float32Array(data.slice(offset, offset+=4))[0];
			pO.headAngle = new Uint8Array(data.slice(offset, offset+=1))[0] / max8 * (Math.PI*2);
			O.players[i] = pO;
			if (pO.id == id) {
				O.me = pO;
			} else
				O.enemies.push(pO);
		}

		var bulletsCount = new Uint8Array(data.slice(offset, offset+=1))[0];
		O.bullets = new Array(bulletsCount);
		for (var i = 0; i < bulletsCount; ++i) {
			var bO = {};
			var d = new Uint8Array(data.slice(offset, offset+=7));
			bO.owner = usernames[d[0]] || '...';
			bO.x = d[1] / max8 * width;
			bO.y = d[2] / max8 * height;
			bO.vx = (d[3] / max8 * 2 - 1) / TPS * 10;
			bO.vy = (d[4] / max8 * 2 - 1) / TPS * 10;
			bO.angle = atan2(bO.vy, bO.vx);
			bO.color = colors[d[5]];
			bO.type = d[6] == 1;
			O.bullets[i] = bO;
		}

		var bulletEventsCount = new Uint8Array(data.slice(offset, offset+=1))[0];
		O.bulletEvents = new Array(bulletEventsCount);
		for (var i = 0; i < bulletEventsCount; ++i) {
			var buO = {};
			var type = new Uint8Array(data.slice(offset, offset+=1))[0];
			if (type == 0) {
				buO.to = 'player';
				buO.username = usernames[new Uint8Array(data.slice(offset, offset+=1))[0]] || '...';
			} else if (type == 1) {
				buO.to = 'wall';
				var d = new Uint16Array(data.slice(offset, offset+=4));
				buO.x = d[0] / max16 * width;
				buO.y = d[1] / max16 * height;
			}
			O.bulletEvents[i] = buO;
		}

		var bonusesCount = new Uint8Array(data.slice(offset, offset+=1))[0];
		O.bonuses = new Array(bonusesCount);
		for (var i = 0; i < bonusesCount; ++i) {
			var bnO = {};
			var d = new Uint8Array(data.slice(offset, offset+=3));
			bnO.type = (['ammo','heal'])[d[0]];
			bnO.x = d[1] / max8 * width;
			bnO.y = d[2] / max8 * height;
			bnO.radius = bonusRadius;
			O.bonuses[i] = bnO;
		}

		O.walls = walls;
		return O;
	} else {
		var count = new Uint8Array(data.slice(offset, offset+=1))[0];
		var O = new Array(count);

		for (var i = 0; i < count; ++i) {
			var p = {};
			var d = new Uint8Array(data.slice(offset, offset+=3));
			p.id = d[0];
			p.place = d[1];
			var uCount = d[2], uname = "...";
			if (uCount != 0) {
				var darr = new Uint8Array(data.slice(offset, offset+=uCount));
				uname = Array.from(darr, function (x) {
					return symbolsRange[x];
				}).join('');
				if (uname == credentials.username)
					id = p.id;
				usernames[p.id] = uname;
			} else if (usernames[p.id])
				uname = usernames[p.id]
			p.username = uname;
			p.points = new Uint32Array(data.slice(offset, offset+=4))[0];
			O[i] = p;
		}
		return {messageType: 'score', scoreboard: O};
	}
}

function toArrayBuffer(buf) {
    var ab = new ArrayBuffer(buf.length);
    var view = new Uint8Array(ab);
    for (var i = 0; i < buf.length; ++i) {
        view[i] = buf[i];
    }
    return ab;
}

global.line = function () {}
global.circle = function () {}
global.point = function () {}
global.text = function () {}
function getGameSessionToken(callback) {
	if (!userToken) {
		HTTPSrequest('POST', '/login', {
			username: credentials.username,
			password: credentials.password
		}, function (obj) {
			if (obj.status == 'ok') {
				userToken = obj.token;
				_getGameSessionToken();
			} else {
				errFatal(JSON.stringify(obj))
			}
		}, function (e) {
			errFatal('Main server request error', e);
		});
	} else
		_getGameSessionToken();

	function _getGameSessionToken() {
		HTTPSrequest('GET', '/play', {
			gameName: 'tanks',
			token: userToken
		}, function (obj) {
			if (obj.status == 'ok') {
				callback(obj.gameSessionToken);
			} else {
				errFatal("Tried to receive gameSessionToken. Error: " + JSON.stringify(obj,null,'\t'));
			}
		}, function (e) {
			errFatal('Main server request error', e);
		})
	}
}
checkGameServer(function () {
	getCredentials(function () {
		start();
	});
})

function HTTPSrequest(method, url, parameters, callback, onerror) {
	var query = Array.from(Object.keys(parameters), function (p) {
		return p + '=' + encodeURIComponent(parameters[p]);
	}).join('&');
	var req = https.request({
		hostname: apiHostname,
		port: apiPort,
		path: url+'?'+query,
		method: method,
		headers: {
			'Accept': 'application/json'
		}
	}, function onConnect(res) {
		var chunks = [];
		res.on('data', function onChunk(chunk) {
			chunks.push(chunk);
		});
		res.on('end', function onEnd() {
			var message = Buffer.concat(chunks).toString();
			callback(JSON.parse(message));
		});

		res.on('error', onerror);
	})
	req.on('error', onerror);
	req.end();
}

function log() {
	console.log('['+'log'.white.bold+'] ' + toArr(arguments).join(' '));
}
function warn(text, e) {
	console.log('['+'warn'.yellow.bold+'] ' + text);
	if (e)
		console.log('['+'warn-trace'.yellow.bold+'] ' + e.toString());
}
function err(text, e) {
	console.log('['+'err'.red.bold+'] ' + text);
	if (e)
		console.log('['+'err-trace'.red.bold+'] ' + e.toString());
}
function errFatal(text, e) {
	err.apply(null, toArr(arguments));
	process.exit(0);
}
function toArr(args) {
	return Array.prototype.slice.call(args);
}