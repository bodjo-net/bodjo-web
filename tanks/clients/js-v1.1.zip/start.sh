node index.js
read -p "Press Enter to exit..."