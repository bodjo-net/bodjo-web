bodjo/tanks bot v1.0 (protocol v2.3)

Инструкция.

1. Зайдите на bodjo.net/tanks в режим зрителя (вкладка "Клиент"). Проверьте, что в вашей адресной строке есть "?type=spectator" и не запущена какая-либо другая вкладка с bodjo.net/tanks
2. Запустите install.sh/install.bat (или запустите в терминале "npm install")
3. Запустите клиент через start.sh/start.bat (или "node index.js" в терминале)
4. Выберите способ подключения (через пароль или gameSessionToken) и введите учетные данные.

your-code-here.js - файл с вашим кодом