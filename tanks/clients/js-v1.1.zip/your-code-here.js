// constants: width, height, tankRadius, walls
// this function is run every tick

function onTick(data) {
	
	return {
		move: [0, 0],
		headAngle: Date.now()/1000*PI,
		shoot: true
	}
}

module.exports = onTick;