npm install
read -p "Press Enter to exit..."