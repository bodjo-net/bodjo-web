import com.bodjo.tank_wrapper.Client
import com.bodjo.tank_wrapper.pojo.GameData
import com.bodjo.tank_wrapper.pojo.ReturnModel
import java.util.*

fun main() {
    Client().run("<your-login>", "<your-password>") { data: GameData ->
        val xv = Random().nextFloat()
        val yv = Random().nextFloat()
        ReturnModel(
            floatArrayOf(xv, yv),
            Random().nextFloat(),
            true
        )
    }
}
